package com.example.BattleInMagicalArena;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BattleInMagicalArenaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BattleInMagicalArenaApplication.class, args);
	}

}
